
//
// Count the number of set bits in an integer value
//
int count_bits(int val)
{
	int count = 0;
	return count;
}


