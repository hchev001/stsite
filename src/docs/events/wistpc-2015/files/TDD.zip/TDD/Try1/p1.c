#include <stdio.h>
#include <stdlib.h>

int count_bits(int);

int main(int argc, char**argv)
{
	int input;
	int set_bits;

	if (argc != 2)
	{
		printf("USAGE:  counts bits on an int argument\n");
		return -1;
	}

	input = atoi(argv[1]);
	set_bits = count_bits(input);

	printf("There are %d bits set in %d\n", set_bits, input);
}
