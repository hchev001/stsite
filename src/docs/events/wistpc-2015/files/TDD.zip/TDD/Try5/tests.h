//
// Define a test case
//
typedef struct {
	int input;
	int expected_output;
} TEST_CASE;


//
// Define all of the test cases we want to run
//
TEST_CASE tests[] = {
	{ 0, 0},
	{ 1, 1},
	{ 2, 1},
	{ 3, 2},
	{ 4, 1},
	{ 7, 3},
	{255, 8},
	{256, 1}
};

