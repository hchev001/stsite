
//
// Count the number of set bits in an integer value
// Kerningham algorithm
//
int count_bits(int val)
{
   unsigned int count = 0;
    while (val)
    {
      val &= (val-1) ;
      count++;
    }
    return count;
}

