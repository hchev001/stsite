
//
// Count the number of set bits in an integer value
//
int count_bits(int val)
{
        int count = 1;
        if (val < 1)
        {
               count = 0;
        }
        return count;
}


//        if (val < 1)
//        {
//               count = 0;
//        }
//        else
//        {
//               count = 1;
//        }


