
int count_bits(int val)
{
	int count =0;
	while (val)
	{
		count += val & 1;
		val = val >> 1;
	}
	return count;
}



