
int count_bits1(int val)
{
	int count = 0;
	return count;
}

int count_bits2(int val)
{
	int count = val;
	return count;
}

int count_bits3(int val)
{
	int count;
	if (val < 1)
	{
		count = 0;
	}
	else
	{
		count = 1;
	}
	return count;
}

int count_bits4(int val)
{
	int count = 0;
	while (val)
	{
		count += val & 1;
		val = val >> 1;
	}
	return count;
}

//
// Count the number of set bits in an integer value
//
int count_bits(int val)
{
	return count_bits4(val);
}

