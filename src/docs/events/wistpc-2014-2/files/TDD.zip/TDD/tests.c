#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//
// Prototype for function under test
//
int count_bits(int);


//
// Define a test case
//
typedef struct {
	int input;
	int expected_output;
} TEST_CASE;

//
// Define all of the test cases we want to run
//
TEST_CASE tests[] = {
	{ 0, 0},
	{ 1, 1},
	{ 2, 1},
	{ 3, 2},
	{ 4, 1},
	{ 7, 3},
	{255, 8},
	{256, 1}
};

int run_test(int test_id, int(f)(int));

int main(int argc, char **argv)
{
	int num_tests;
	int error_count = 0;
	int pass_count;

	if (argc == 2)
	{
		num_tests = atoi(argv[1]);
	}
	else
	{
		num_tests = sizeof(tests)/sizeof(TEST_CASE);
	}
	
	for (int test_num = 0; test_num < num_tests; test_num++)
	{
		error_count += run_test(test_num, count_bits);
	}

	pass_count = num_tests - error_count;
	printf("Run: %d, Pass: %d, Fail: %d\n",
			num_tests, pass_count, error_count);

	return error_count;
}

int run_test(int test_id, int(f)(int))
{
	TEST_CASE t = tests[test_id];

	int input = t.input;
	int expected_output = t.expected_output;
	int actual_output;
	int error_count = 0;

	actual_output = f(input);

	if (actual_output == expected_output)
	{
		printf("PASS state test %d\n", test_id);
	}
        else
	{
		printf("FAIL test %d:  expected %d actual %d\n",
			test_id, expected_output, actual_output);
		error_count++;
	}

	return error_count;
}

