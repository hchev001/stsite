package model;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class WebElementWrapper {

	private WebElement underlyingElement;
	
	public WebElementWrapper(WebElement underlyingElement) {
		this.underlyingElement = underlyingElement;
	}
	
	public WebElementWrapper clear() {
		underlyingElement.clear();
		return this;
	}
	
	public WebElementWrapper sendKeys(String keys) {
		underlyingElement.sendKeys(keys);
		return this;
	}

	public WebElementWrapper click() {
		underlyingElement.click();
		return this;
	}
	
	public String getText() {
		return underlyingElement.getText();
	}
}
