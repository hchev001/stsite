package model;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MortgageCalculatorImproved {
	private WebDriver driver;
	
	public MortgageCalculatorImproved(WebDriver driver) {
		this.driver = driver;
		driver.navigate().to("http://www.mortgagecalculator.org/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	public WebElementWrapper homeValueTextBox() {
		return new WebElementWrapper(driver.findElement(By.name("param[homevalue]")));
	}
	
	public WebElementWrapper loanAmountTextBox() {
		return new WebElementWrapper(driver.findElement(By.id("loanamt")));
	}
	
	public WebElementWrapper calculateButton() {
		return new WebElementWrapper(driver.findElement(By.name("cal")));
	}
	
	public WebElementWrapper repaymentSummaryMonthlyPayment() {
		return new WebElementWrapper(driver.findElement(By.cssSelector("[class=repayment-block] > .rw-box:nth-child(1) > .left-cell > h3")));
	}
	
	public void quit() {
		driver.quit();
	}
}
