package model;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class MortgageCalculator {
	
	private WebDriver driver;
	
	public MortgageCalculator(WebDriver driver) {
		this.driver = driver;
		driver.navigate().to("http://www.mortgagecalculator.org/");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	
	public WebElement homeValueTextBox() {
		return driver.findElement(By.name("param[homevalue]"));
	}
	
	public WebElement loanAmountTextBox() {
		return driver.findElement(By.id("loanamt"));
	}
	
	public WebElement calculateButton() {
		return driver.findElement(By.name("cal"));
	}
	
	public WebElement repaymentSummaryMonthlyPayment() {
		return driver.findElement(By.cssSelector("[class=repayment-block] > .rw-box:nth-child(1) > .left-cell > h3"));
	}
	
	public void quit() {
		driver.quit();
	}
}
