package practice;

import static org.junit.Assert.*;

import java.util.concurrent.TimeUnit;

import model.MortgageCalculator;
import model.MortgageCalculatorImproved;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MortgageCalcTests {

	WebDriver driver;
	
	@Before
	public void setUp() {
		driver = new ChromeDriver();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		driver.navigate().to("http://www.mortgagecalculator.org/");
	}

	@After
	public void tearDown() {
		driver.quit();
	}

	@Test
	public void testSimpleCalculation() throws InterruptedException {
		WebElement homeValueInput = driver.findElement(By.name("param[homevalue]"));
		homeValueInput.clear();
		homeValueInput.sendKeys("250000");
		
		WebElement loanAmountInput = driver.findElement(By.name("param[principal]"));
		loanAmountInput.clear();
		loanAmountInput.sendKeys("225000");
		
		driver.findElement(By.name("cal")).click();
		
		// $1,334.60
		WebElement mortgageRepaymentMonthly =
				driver.findElement(By.cssSelector("[class=repayment-block] > .rw-box:nth-child(1) > .left-cell > h3"));
	
		assertEquals("$1,506.04", mortgageRepaymentMonthly.getText());
	}

}










