package solution;

import static org.junit.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import model.MortgageCalculator;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class MortageCalculatorTestsOriginal {

	WebDriver driver;
	
	@Before
	public void setUp() {
        driver = new ChromeDriver();
        driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
        driver.navigate().to("http://www.mortgagecalculator.org/");
	}
	
	@After
	public void tearDown() {
		driver.quit();
	}
	
	@Test
	public void testSimpleCalculation() {
		// Arrange.
		WebElement homeValueInput = 
				driver.findElement(By.name("param[homevalue]"));
		homeValueInput.clear();
		homeValueInput.sendKeys("250000");
		
		WebElement loanAmountInput = 
				driver.findElement(By.id("loanamt"));
		loanAmountInput.clear();
		loanAmountInput.sendKeys("225000");
		
		// Act.
		driver.findElement(By.name("cal")).click();
		
		// Assert.
		WebElement repaymentMonthlyPayment = 
				driver.findElement(By.cssSelector("[class=repayment-block] > .rw-box:nth-child(1) > .left-cell > h3"));
		
		assertEquals("$1,334.60", repaymentMonthlyPayment.getText());
	}
}
