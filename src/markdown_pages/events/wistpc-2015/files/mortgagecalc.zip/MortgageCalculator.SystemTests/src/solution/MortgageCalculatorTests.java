package solution;
import static org.junit.Assert.*;
import model.MortgageCalculator;
import model.MortgageCalculatorImproved;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runners.Parameterized.Parameters;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.WebDriverWait;

public class MortgageCalculatorTests {

	MortgageCalculatorImproved model;
	
	@Before
	public void setUp() {
        model = new MortgageCalculatorImproved(new ChromeDriver());
	}
	
	@After
	public void tearDown() {
		model.quit();
	}
	
	@Test
	public void testSimpleCalculation() {
		
		// Arrange.
		model.homeValueTextBox().clear().sendKeys("250000");
		model.loanAmountTextBox().clear().sendKeys("225000");
		
		// Act.
		model.calculateButton().click();
		
		// Assert.
		assertEquals("$1,334.60", model.repaymentSummaryMonthlyPayment().getText());
		
	}

}
